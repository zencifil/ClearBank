﻿namespace ClearBank.DeveloperTest.Types
{
    public enum PaymentScheme
    {
        FasterPayments,
        Bacs,
        Chaps
    }
}
